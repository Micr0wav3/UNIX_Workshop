#!/bin/bash
# this script will set the correct permissions for the files if they are missing their correct permissions
chmod 400 log.log
chmod 600 script.sh
