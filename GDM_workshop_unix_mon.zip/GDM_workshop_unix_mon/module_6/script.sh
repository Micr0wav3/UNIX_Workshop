#!/bin/bash
echo "The script has run once"
echo "-----------------------"
